# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['panchemy']
setup_kwargs = {
    'name': 'panchemy',
    'version': '0.1.0',
    'description': 'A library for data handler between SQLAlchemy and pandas',
    'long_description': None,
    'author': 'Alan Nguyen',
    'author_email': 'nnlan.dev.98@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
